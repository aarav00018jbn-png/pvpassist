package com.example.pvpassist;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.tree.CommandNode;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class PvpCommands {
    private PvpCommands() {
    }

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("pvpassist");

            // /pvpassist toggle <feature>
            LiteralArgumentBuilder<FabricClientCommandSource> toggle = ClientCommandManager.literal("toggle");
            for (String f : PvpConfig.FEATURES) {
                toggle.then(ClientCommandManager.literal(f).executes(ctx -> {
                    PvpConfig c = PvpAssistClient.config();
                    boolean now = !c.get(f);
                    c.set(f, now);
                    c.save();
                    if (f.equals("aim") && now) {
                        TargetTracker.resetTraining();
                    }
                    reply(ctx, "PvP Assist: " + f + " = " + (now ? "ON" : "OFF"));
                    return 1;
                }));
            }
            root.then(toggle);

            // /pvpassist target [clear]
            root.then(ClientCommandManager.literal("target")
                    .executes(ctx -> {
                        reply(ctx, TargetTracker.select(MinecraftClient.getInstance()));
                        return 1;
                    })
                    .then(ClientCommandManager.literal("clear").executes(ctx -> {
                        TargetTracker.clearSelection();
                        reply(ctx, "Target cleared (HUD follows the nearest player).");
                        return 1;
                    })));

            // /pvpassist radius <8-128>
            root.then(ClientCommandManager.literal("radius")
                    .then(ClientCommandManager.argument("blocks", IntegerArgumentType.integer(8, 128))
                            .executes(ctx -> {
                                PvpConfig c = PvpAssistClient.config();
                                c.detectionRadius = IntegerArgumentType.getInteger(ctx, "blocks");
                                c.save();
                                reply(ctx, "Detection radius = " + c.detectionRadius);
                                return 1;
                            })));

            // /pvpassist reset  (aim-training stats)
            root.then(ClientCommandManager.literal("reset").executes(ctx -> {
                TargetTracker.resetTraining();
                reply(ctx, "Aim-training stats reset.");
                return 1;
            }));

            // /pvpassist status (also the default)
            root.then(ClientCommandManager.literal("status").executes(PvpCommands::status));
            root.executes(PvpCommands::status);

            CommandNode<FabricClientCommandSource> node = dispatcher.register(root);
            dispatcher.register(ClientCommandManager.literal("pva").redirect(node));
        });
    }

    private static int status(CommandContext<FabricClientCommandSource> ctx) {
        PvpConfig c = PvpAssistClient.config();
        StringBuilder sb = new StringBuilder("PvP Assist status:");
        for (String f : PvpConfig.FEATURES) {
            sb.append("\n  ").append(f).append(" = ").append(c.get(f) ? "ON" : "OFF");
        }
        sb.append("\n  radius = ").append(c.detectionRadius);
        sb.append("\nCommands: toggle <feature>, target [clear], radius <n>, reset, status");
        reply(ctx, sb.toString());
        return 1;
    }

    private static void reply(CommandContext<FabricClientCommandSource> ctx, String msg) {
        ctx.getSource().sendFeedback(Text.literal(msg));
    }
}
