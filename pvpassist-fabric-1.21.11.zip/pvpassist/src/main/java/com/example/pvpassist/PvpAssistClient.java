package com.example.pvpassist;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class PvpAssistClient implements ClientModInitializer {
    public static final String MOD_ID = "pvpassist";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static PvpConfig config = new PvpConfig();

    public static PvpConfig config() {
        return config;
    }

    @Override
    public void onInitializeClient() {
        config = PvpConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(TargetTracker::tick);
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of(MOD_ID, "hud"),
                HudRenderer::render);
        PvpCommands.register();
        LOGGER.info("PvP Assist loaded (client-side information only).");
    }
}
