package com.example.pvpassist;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Reads information the client already has (entity positions, synced health) and turns it
 * into display values. It never changes the player's rotation or sends any input.
 */
public final class TargetTracker {
    /** relYaw: positive = target is to your right. relPitch: positive = target is below your crosshair. */
    public record Info(int id, String name, double distance, double reach, double range,
                       float relYaw, float relPitch,
                       boolean hasHealth, float health, float maxHealth, float absorption) {
    }

    public static final float AIM_TOLERANCE = 5.0f;

    private static List<Info> nearby = List.of();
    private static Info primary = null;
    private static boolean selectedHidden = false;
    private static int selectedId = -1;
    private static int trainTicks = 0;
    private static int trainHits = 0;

    private TargetTracker() {
    }

    public static List<Info> nearby() {
        return nearby;
    }

    public static Info primary() {
        return primary;
    }

    public static boolean isSelectedHidden() {
        return selectedHidden;
    }

    public static boolean hasSelection() {
        return selectedId != -1;
    }

    public static int trainingPercent() {
        return trainTicks == 0 ? 0 : Math.round(100f * trainHits / trainTicks);
    }

    public static int trainingTicks() {
        return trainTicks;
    }

    public static void resetTraining() {
        trainTicks = 0;
        trainHits = 0;
    }

    public static void clearSelection() {
        selectedId = -1;
        resetTraining();
    }

    public static String select(MinecraftClient client) {
        Entity hit = client.targetedEntity;
        if (hit instanceof LivingEntity le && le.isAlive()) {
            selectedId = le.getId();
            resetTraining();
            return "Selected target: " + le.getName().getString();
        }
        if (!nearby.isEmpty()) {
            Info n = nearby.get(0);
            selectedId = n.id();
            resetTraining();
            return "Selected nearest player: " + n.name();
        }
        return "No entity under your crosshair and no player nearby.";
    }

    public static void tick(MinecraftClient client) {
        PvpConfig cfg = PvpAssistClient.config();
        ClientPlayerEntity self = client.player;
        ClientWorld world = client.world;
        if (self == null || world == null || !cfg.enabled) {
            nearby = List.of();
            primary = null;
            selectedHidden = false;
            return;
        }

        // Nearby players (skip spectators and invisible players; optionally require line of sight).
        List<PlayerEntity> found = new ArrayList<>();
        double r2 = (double) cfg.detectionRadius * cfg.detectionRadius;
        for (PlayerEntity p : world.getPlayers()) {
            if (p == self || p.isSpectator() || p.isInvisible() || !p.isAlive()) {
                continue;
            }
            if (self.squaredDistanceTo(p) > r2) {
                continue;
            }
            if (cfg.visibleTargetsOnly && !self.canSee(p)) {
                continue;
            }
            found.add(p);
        }
        found.sort((a, b) -> Double.compare(self.squaredDistanceTo(a), self.squaredDistanceTo(b)));

        List<Info> list = new ArrayList<>();
        for (PlayerEntity p : found) {
            if (list.size() >= cfg.maxListed) {
                break;
            }
            list.add(describe(self, p));
        }
        nearby = list;

        // Selected target (practice target) or fall back to the nearest listed player.
        selectedHidden = false;
        Info chosen = null;
        if (selectedId != -1) {
            Entity e = world.getEntityById(selectedId);
            if (e instanceof LivingEntity le && le.isAlive() && !le.isRemoved()) {
                if (cfg.visibleTargetsOnly && !self.canSee(le)) {
                    selectedHidden = true;
                } else {
                    chosen = describe(self, le);
                }
            } else {
                selectedId = -1;
                resetTraining();
            }
        }
        if (chosen == null && selectedId == -1 && !list.isEmpty()) {
            chosen = list.get(0);
        }
        primary = chosen;

        // Aim-training statistics (only counts while the mode is on and a target is visible).
        if (cfg.aimTraining && chosen != null) {
            trainTicks++;
            if (Math.abs(chosen.relYaw()) <= AIM_TOLERANCE && Math.abs(chosen.relPitch()) <= AIM_TOLERANCE) {
                trainHits++;
            }
        }
    }

    private static Info describe(ClientPlayerEntity self, LivingEntity t) {
        Box b = t.getBoundingBox();
        double ex = self.getX();
        double ey = self.getEyeY();
        double ez = self.getZ();

        // Eye-to-hitbox distance (what melee reach is measured against).
        double cx = MathHelper.clamp(ex, b.minX, b.maxX);
        double cy = MathHelper.clamp(ey, b.minY, b.maxY);
        double cz = MathHelper.clamp(ez, b.minZ, b.maxZ);
        double rx = cx - ex;
        double ry = cy - ey;
        double rz = cz - ez;
        double reach = Math.sqrt(rx * rx + ry * ry + rz * rz);

        // Direction to the hitbox centre, relative to where you are currently looking.
        double tx = (b.minX + b.maxX) / 2.0;
        double ty = (b.minY + b.maxY) / 2.0;
        double tz = (b.minZ + b.maxZ) / 2.0;
        double dx = tx - ex;
        double dy = ty - ey;
        double dz = tz - ez;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float targetPitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));
        float relYaw = MathHelper.wrapDegrees(targetYaw - self.getYaw());
        float relPitch = targetPitch - self.getPitch();

        float hp = t.getHealth();
        boolean hasHealth = !Float.isNaN(hp) && hp > 0.0f;

        return new Info(
                t.getId(),
                t.getName().getString(),
                self.distanceTo(t),
                reach,
                self.getEntityInteractionRange(),
                relYaw,
                relPitch,
                hasHealth,
                hp,
                t.getMaxHealth(),
                t.getAbsorptionAmount());
    }
}
