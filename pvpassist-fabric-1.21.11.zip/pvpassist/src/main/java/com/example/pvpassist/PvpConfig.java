package com.example.pvpassist;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public final class PvpConfig {
    /** Feature keys usable with /pvpassist toggle <key>. */
    public static final List<String> FEATURES =
            List.of("master", "detection", "hud", "aim", "reach", "cooldown", "health", "visible");

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean enabled = true;
    public boolean enemyDetection = true;
    public boolean combatHud = true;
    public boolean aimTraining = false;
    public boolean reachIndicator = true;
    public boolean cooldownIndicator = true;
    public boolean showTargetHealth = true;
    /** Only list/track players you could see with a clear line of sight (fair-play default). */
    public boolean visibleTargetsOnly = true;

    public int detectionRadius = 32;
    public int maxListed = 5;
    public int panelX = 6;
    public int panelY = 6;

    public boolean get(String f) {
        return switch (f) {
            case "master" -> enabled;
            case "detection" -> enemyDetection;
            case "hud" -> combatHud;
            case "aim" -> aimTraining;
            case "reach" -> reachIndicator;
            case "cooldown" -> cooldownIndicator;
            case "health" -> showTargetHealth;
            case "visible" -> visibleTargetsOnly;
            default -> false;
        };
    }

    public void set(String f, boolean v) {
        switch (f) {
            case "master" -> enabled = v;
            case "detection" -> enemyDetection = v;
            case "hud" -> combatHud = v;
            case "aim" -> aimTraining = v;
            case "reach" -> reachIndicator = v;
            case "cooldown" -> cooldownIndicator = v;
            case "health" -> showTargetHealth = v;
            case "visible" -> visibleTargetsOnly = v;
            default -> { }
        }
    }

    public void clamp() {
        detectionRadius = Math.max(8, Math.min(128, detectionRadius));
        maxListed = Math.max(1, Math.min(10, maxListed));
        panelX = Math.max(0, panelX);
        panelY = Math.max(0, panelY);
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvpassist.json");
    }

    public static PvpConfig load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                PvpConfig c = GSON.fromJson(r, PvpConfig.class);
                if (c != null) {
                    c.clamp();
                    return c;
                }
            } catch (IOException | RuntimeException e) {
                PvpAssistClient.LOGGER.warn("Could not read config, using defaults", e);
            }
        }
        PvpConfig c = new PvpConfig();
        c.save();
        return c;
    }

    public void save() {
        try {
            Path p = path();
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p)) {
                GSON.toJson(this, w);
            }
        } catch (IOException e) {
            PvpAssistClient.LOGGER.warn("Could not save config", e);
        }
    }
}
