package com.example.pvpassist;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class HudRenderer {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int GREEN = 0xFF55FF55;
    private static final int RED = 0xFFFF5555;
    private static final int YELLOW = 0xFFFFFF55;
    private static final int AQUA = 0xFF55FFFF;
    private static final int LINE_HEIGHT = 10;

    private record Line(String text, int color) {
    }

    private HudRenderer() {
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PvpConfig cfg = PvpAssistClient.config();
        if (mc.player == null || mc.world == null || mc.options.hudHidden || !cfg.enabled) {
            return;
        }
        TextRenderer tr = mc.textRenderer;

        drawPanel(ctx, tr, cfg);

        if (cfg.cooldownIndicator) {
            drawCooldown(ctx, mc, tr);
        }
        if (cfg.aimTraining) {
            drawAimTrainer(ctx, mc, tr);
        }
    }

    // ---------------------------------------------------------------- info panel

    private static void drawPanel(DrawContext ctx, TextRenderer tr, PvpConfig cfg) {
        List<Line> lines = new ArrayList<>();
        TargetTracker.Info t = TargetTracker.primary();

        if (cfg.enemyDetection) {
            List<TargetTracker.Info> nearby = TargetTracker.nearby();
            lines.add(new Line("Nearby players (" + nearby.size() + ")", AQUA));
            if (nearby.isEmpty()) {
                lines.add(new Line("  none in range", GRAY));
            }
            for (TargetTracker.Info n : nearby) {
                String marker = (t != null && t.id() == n.id()) ? "> " : "  ";
                lines.add(new Line(marker + n.name() + "  " + fmt(n.distance()) + "m  " + direction(n.relYaw()), WHITE));
            }
        }

        if (cfg.combatHud || cfg.reachIndicator) {
            if (t != null) {
                if (cfg.combatHud) {
                    lines.add(new Line("Target: " + t.name(), AQUA));
                    lines.add(new Line("Distance: " + fmt(t.distance()) + "m   Attack range: " + fmt(t.range()), WHITE));
                    if (cfg.showTargetHealth && t.hasHealth()) {
                        String hp = "Health: " + fmt(t.health()) + " / " + fmt(t.maxHealth());
                        if (t.absorption() > 0.0f) {
                            hp += " (+" + fmt(t.absorption()) + ")";
                        }
                        lines.add(new Line(hp, healthColor(t.health(), t.maxHealth())));
                    }
                }
                if (cfg.reachIndicator) {
                    boolean in = t.reach() <= t.range();
                    String s = "Reach: " + fmt(t.reach()) + "m  "
                            + (in ? "[IN RANGE]" : "[OUT +" + fmt(t.reach() - t.range()) + "]");
                    lines.add(new Line(s, in ? GREEN : RED));
                }
            } else if (TargetTracker.isSelectedHidden()) {
                lines.add(new Line("Selected target not visible", YELLOW));
            } else if (cfg.combatHud) {
                lines.add(new Line("No target", GRAY));
            }
        }

        if (lines.isEmpty()) {
            return;
        }

        int w = 0;
        for (Line l : lines) {
            w = Math.max(w, tr.getWidth(l.text()));
        }
        int x = cfg.panelX;
        int y = cfg.panelY;
        int h = lines.size() * LINE_HEIGHT;
        ctx.fill(x - 3, y - 3, x + w + 3, y + h + 1, 0x90000000);
        int cy = y;
        for (Line l : lines) {
            ctx.drawTextWithShadow(tr, l.text(), x, cy, l.color());
            cy += LINE_HEIGHT;
        }
    }

    // ---------------------------------------------------------------- cooldown

    private static void drawCooldown(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        float p = MathHelper.clamp(mc.player.getAttackCooldownProgress(0.0f), 0.0f, 1.0f);
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int cx = sw / 2;
        int y = sh / 2 + 14;
        int half = 16;
        ctx.fill(cx - half - 1, y - 1, cx + half + 1, y + 4, 0x90000000);
        int filled = Math.round(2 * half * p);
        int color = p >= 1.0f ? GREEN : (p > 0.6f ? YELLOW : RED);
        ctx.fill(cx - half, y, cx - half + filled, y + 3, color);
        if (p >= 1.0f) {
            String s = "READY";
            ctx.drawTextWithShadow(tr, s, cx - tr.getWidth(s) / 2, y + 6, GREEN);
        }
    }

    // ---------------------------------------------------------------- aim trainer

    private static void drawAimTrainer(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        int sw = mc.getWindow().getScaledWidth();
        int w = 160;
        int h = 40;
        int x = (sw - w) / 2;
        int y = 24;

        ctx.fill(x, y, x + w, y + h, 0x80000000);
        box(ctx, x, y, x + w, y + h, 0xFF808080);
        ctx.fill(x + w / 2, y, x + w / 2 + 1, y + h, 0x60FFFFFF);
        ctx.fill(x, y + h / 2, x + w, y + h / 2 + 1, 0x60FFFFFF);

        TargetTracker.Info t = TargetTracker.primary();
        String hint;
        int hintColor = WHITE;
        if (t == null) {
            hint = TargetTracker.isSelectedHidden()
                    ? "Target not visible"
                    : "Aim training: use /pvpassist target";
            hintColor = GRAY;
        } else {
            float ry = MathHelper.clamp(t.relYaw(), -90.0f, 90.0f);
            float rp = MathHelper.clamp(t.relPitch(), -45.0f, 45.0f);
            int dotX = x + w / 2 + Math.round(ry / 90.0f * (w / 2 - 4));
            int dotY = y + h / 2 + Math.round(rp / 45.0f * (h / 2 - 4));
            boolean on = Math.abs(t.relYaw()) <= TargetTracker.AIM_TOLERANCE
                    && Math.abs(t.relPitch()) <= TargetTracker.AIM_TOLERANCE;
            ctx.fill(dotX - 3, dotY - 3, dotX + 3, dotY + 3, on ? GREEN : RED);

            if (on) {
                hint = "ON TARGET";
                hintColor = GREEN;
            } else {
                StringBuilder sb = new StringBuilder();
                if (Math.abs(t.relYaw()) > 90.0f) {
                    sb.append("Behind you - turn ").append(t.relYaw() > 0 ? "right" : "left");
                } else if (Math.abs(t.relYaw()) > TargetTracker.AIM_TOLERANCE) {
                    sb.append("Turn ").append(t.relYaw() > 0 ? "right " : "left ")
                            .append(Math.round(Math.abs(t.relYaw()))).append('\u00b0');
                }
                if (Math.abs(t.relPitch()) > TargetTracker.AIM_TOLERANCE) {
                    if (sb.length() > 0) {
                        sb.append(", ");
                    }
                    sb.append("look ").append(t.relPitch() > 0 ? "down " : "up ")
                            .append(Math.round(Math.abs(t.relPitch()))).append('\u00b0');
                }
                hint = sb.toString();
            }
        }
        ctx.drawTextWithShadow(tr, hint, (sw - tr.getWidth(hint)) / 2, y + h + 4, hintColor);

        if (TargetTracker.trainingTicks() > 0) {
            String acc = "On target: " + TargetTracker.trainingPercent() + "%";
            ctx.drawTextWithShadow(tr, acc, (sw - tr.getWidth(acc)) / 2, y + h + 4 + LINE_HEIGHT, GRAY);
        }
    }

    // ---------------------------------------------------------------- helpers

    private static void box(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y1 + 1, color);
        ctx.fill(x1, y2 - 1, x2, y2, color);
        ctx.fill(x1, y1, x1 + 1, y2, color);
        ctx.fill(x2 - 1, y1, x2, y2, color);
    }

    private static String fmt(double v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    private static String direction(float relYaw) {
        float a = Math.abs(relYaw);
        if (a < 10.0f) {
            return "ahead";
        }
        if (a > 150.0f) {
            return "behind";
        }
        return (relYaw > 0 ? "right " : "left ") + Math.round(a) + "\u00b0";
    }

    private static int healthColor(float hp, float max) {
        float f = max <= 0 ? 0 : hp / max;
        return f > 0.6f ? GREEN : (f > 0.3f ? YELLOW : RED);
    }
}
