# PvP Assist (Fabric, Minecraft 1.21.11)

Client-side information HUD: nearby players, target distance/health, attack range,
reach indicator, attack-cooldown indicator, and an aim-training guide.

Fair play: it never rotates your camera, never attacks, never sends packets, and never
touches anti-cheat. Invisible players and spectators are ignored, and by default only
players you have line of sight to are shown. Always check your server's rules.

## Versions
Minecraft 1.21.11 | Fabric Loader >= 0.18.4 | Fabric API 0.141.5+1.21.11 | Yarn 1.21.11+build.4 | Loom 1.14 | Java 21

## Build
Option A (PC): install JDK 21 + Gradle 9.2.1+, then `gradle build`. Jar: build/libs/pvpassist-1.0.0.jar
Option B (phone only): push this folder to a GitHub repo; Actions > "build" > run; download the
`pvpassist-jar` artifact (use the file WITHOUT "-sources").

## Commands (type in chat; /pva is an alias)
/pvpassist status
/pvpassist toggle <master|detection|hud|aim|reach|cooldown|health|visible>
/pvpassist target        (select entity under crosshair, else nearest player)
/pvpassist target clear
/pvpassist radius <8-128>
/pvpassist reset         (aim-training stats)

Config file: config/pvpassist.json (panel position, radius, list size, toggles).
